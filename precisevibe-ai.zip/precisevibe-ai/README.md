# PreciseVibe AI 🚀

AI-powered website generator. Describe any website → get pixel-perfect code instantly.

## Folder Structure
```
precisevibe-ai/
├── api/
│   └── generate.js       ← Gemini API (serverless, key stays SECRET)
├── public/
│   └── index.html        ← Full frontend
├── vercel.json           ← Routing config
└── README.md
```

## Deploy to Vercel (Step by Step)

### Step 1 — Upload to GitHub
1. Go to github.com → New repository → name it `precisevibe-ai`
2. Upload all 4 files maintaining the folder structure
3. Click "Commit changes"

### Step 2 — Deploy on Vercel
1. Go to vercel.com → Login with GitHub
2. Click "Add New Project" → Import `precisevibe-ai` repo
3. Click Deploy (don't change any settings)

### Step 3 — Add Secret API Key (CRITICAL)
1. In Vercel dashboard → Your project → Settings → Environment Variables
2. Add:
   - Name: `GEMINI_API_KEY`
   - Value: `AIzaSyB8ZeyJCtMTPB-OBDUNbanwAdQUZh9_z6Y`
3. Click Save → Go to Deployments → Redeploy

### Step 4 — Enable Firebase Auth
1. Go to Firebase Console → Authentication → Sign-in method
2. Enable "Google" provider
3. Add your Vercel URL to "Authorized domains"

## Features
- ✅ Google Login (Firebase Auth)
- ✅ 3 free credits/day per user
- ✅ Gemini API key hidden on server (never exposed)
- ✅ Live iframe preview
- ✅ Download HTML
- ✅ Past projects saved in Firestore
- ✅ Mobile responsive
- ✅ Pro upgrade banner (₹299/month)

## Credit System
- Free: 3 generations/day
- Pro: Unlimited (you can add Razorpay later)
- Stored in Firestore: `users/{uid}.creditsRemaining`
