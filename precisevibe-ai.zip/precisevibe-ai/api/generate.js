export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const { prompt } = req.body;
  if (!prompt) return res.status(400).json({ error: 'Prompt required' });

  const GEMINI_KEY = process.env.GEMINI_API_KEY;

  const systemPrompt = `You are PreciseVibe AI — an expert web developer who generates complete, stunning, production-ready single-file HTML websites based on user prompts.

RULES:
1. Always return ONLY raw HTML code. No markdown, no backticks, no explanation.
2. Every website must be a single self-contained HTML file with embedded CSS and JS.
3. Use CDN links for all libraries (Three.js, GSAP, Tailwind, etc.)
4. Detect keywords and apply smart features:
   - "3D" or "car" or "product" → Use Three.js with geometric shapes/animation
   - "animation" or "scroll" → Use GSAP ScrollTrigger
   - "glass" or "glassmorphism" → CSS backdrop-filter effects
   - "neon" or "dark" → Dark theme with neon glows
   - "luxury" or "premium" → Elegant typography, gold accents
   - "landing" → Full hero + features + CTA sections
   - "portfolio" → Project cards + about + contact
   - "dashboard" → Charts + stats + sidebar layout
5. Always include:
   - Smooth scroll behavior
   - Mobile responsive design
   - Beautiful typography (Google Fonts)
   - Micro-animations on hover/scroll
   - Professional color palette matching the theme
6. Make it VISUALLY STUNNING — not generic. Real businesses would pay for this.

CRITICAL: Output ONLY the HTML. Start with <!DOCTYPE html> and end with </html>. Nothing else.`;

  try {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${GEMINI_KEY}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ parts: [{ text: `${systemPrompt}\n\nUser request: ${prompt}` }] }],
          generationConfig: { temperature: 0.9, maxOutputTokens: 8192 }
        })
      }
    );

    const data = await response.json();
    if (!response.ok) throw new Error(data.error?.message || 'Gemini API error');

    let html = data.candidates?.[0]?.content?.parts?.[0]?.text || '';
    html = html.replace(/```html/gi, '').replace(/```/g, '').trim();

    if (!html.includes('<!DOCTYPE') && !html.includes('<html')) {
      throw new Error('Invalid HTML generated');
    }

    res.status(200).json({ html });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}
